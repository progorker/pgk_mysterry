/*
 * Copyright (c) 2026 Dinh Thoai Tran <zinospetrel@sdf.org>
 * All rights reserved.
 *
 * + Source URL: https://github.com/progorker/mysterry/
 *
 * + License: GPL-2.0
 */

drop procedure if exists test_requests;
delimiter $$
create procedure test_requests( in p_token varchar(36), in p_suite_code varchar(640) )
sql security invoker
begin
  declare v_suite_id int;
  declare v_case_id int;
  declare v_test_id int;
  declare v_error_message text;
  declare v_test_code varchar(640);
  declare v_num_operand double;
  declare v_num_value double;
  declare v_request longtext;
  declare v_sterry_host varchar(8192);
  declare v_sterry_port bigint;
  declare v_sterry_auth_token varchar(8192);
  declare v_sterry_json_data longtext;
  declare v_sterry_path varchar(8192);

  declare exit handler for sqlexception
  begin
    get diagnostics condition 1 v_error_message = message_text;
    call mytestorproxy.api_testor_suite_case( p_token, v_suite_id, v_case_id, p_suite_code, 'test_requests' );
    call mytestorproxy.api_testor_error( p_token, v_test_id, v_suite_id, v_case_id, 'exception', v_error_message );
  end;

  call mytestorproxy.api_testor_suite_case( p_token, v_suite_id, v_case_id, p_suite_code, 'test_requests' );

  set v_test_id = -1;
  set v_test_code = 'equals.1';
  set v_num_operand = 2.5;
  set v_num_value = 2.5;
  call mytestorproxy.api_testor_equals( p_token, v_test_id, v_suite_id, v_case_id, v_test_code, v_num_operand, v_num_value );

  set v_request = concat( '192.168.89.203\r\n8311\r\n_\r\n_\r\n/\r\n\r\n' );
  set v_sterry_host = '';
  set v_sterry_port = -1;
  set v_sterry_path = '';
  set v_sterry_auth_token = '';
  set v_sterry_json_data = '';

  call sterry_parse_request( v_request, v_sterry_host, v_sterry_port, v_sterry_auth_token, v_sterry_json_data, v_sterry_path );

  call mytestorproxy.api_testor_same( p_token, v_suite_id, v_case_id, p_suite_code, 'chaos.1', v_sterry_host, '192.168.89.203' );

end;$$
delimiter ;
