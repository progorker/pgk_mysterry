/*
 * Copyright (c) 2026 Dinh Thoai Tran <zinospetrel@sdf.org>
 * All rights reserved.
 *
 * + Source URL: https://github.com/progorker/mysterry/
 *
 * + License: GPL-2.0
 */

-- \. ./procedure/procedure_test_numbers.sql
