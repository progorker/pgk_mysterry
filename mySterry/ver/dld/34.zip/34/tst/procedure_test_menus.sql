/*
 * Copyright (c) 2026 Dinh Thoai Tran <zinospetrel@sdf.org>
 * All rights reserved.
 *
 * + Source URL: https://github.com/progorker/mysterry/
 *
 * + License: GPL-2.0
 */

drop procedure if exists test_menus;
delimiter $$
create procedure test_menus( in p_token varchar(36), in p_suite_code varchar(640) )
sql security invoker
begin
  declare v_suite_id int;
  declare v_case_id int;
  declare v_test_id int;
  declare v_error_message text;

  declare exit handler for sqlexception
  begin
    get diagnostics condition 1 v_error_message = message_text;
    call mytestorproxy.api_testor_suite_case( p_token, v_suite_id, v_case_id, p_suite_code, 'test_menus' );
    call mytestorproxy.api_testor_error( p_token, v_test_id, v_suite_id, v_case_id, 'exception', v_error_message );
  end;

  call mytestorproxy.api_testor_suite_case( p_token, v_suite_id, v_case_id, p_suite_code, 'test_menus' );

  call mytestorproxy.api_testor_error( p_token, v_test_id, v_suite_id, v_case_id, 'exception.1', 'Fresh test case is created!' );
end;$$
delimiter ;
